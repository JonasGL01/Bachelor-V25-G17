""" Leap Package (vendored) """

# Import the CFFI backend from the vendored leapc_cffi package
from my_leap_pkg.leapc_cffi import ffi, libleapc

# Controller alias for backward compatibility
from .connection import Connection
Controller = Connection

# Expose core functions and classes
from .functions import (
    get_now,
    get_server_status,
    get_frame_size,
    interpolate_frame,
    get_extrinsic_matrix,
)
from .connection import Connection
from .enums import EventType, TrackingMode, HandType
from .event_listener import Listener
from .exceptions import LeapError
from .recording import Recording, Recorder
