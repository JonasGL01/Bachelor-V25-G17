#!/usr/bin/env python3
from my_leap_pkg import leap
import time
import math

"""Prints the palm yaw rotation and the index finger joint pitch angles for every tracking frame."""

class MyListener(leap.Listener):
    def on_connection_event(self, event):
        print("Connected to Leap device")

    def on_device_event(self, event):
        try:
            with event.device.open():
                info = event.device.get_info()
        except leap.LeapCannotOpenDeviceError:
            info = event.device.get_info()
        print(f"Found device {info.serial}")

    def on_tracking_event(self, event):
        # Print frame info
        print(f"Frame {event.tracking_frame_id} with {len(event.hands)} hands.")

        for hand in event.hands:
            # Palm yaw rotation around Y-axis, zero when palm.dir points backward (sensor-facing)
            palm_dir = hand.palm.direction
            raw_yaw = math.degrees(math.atan2(palm_dir.x, palm_dir.z))
            # Shift zero by 180°: now raw_yaw=0 when palm_dir.z<0
            yaw = (raw_yaw + 180) % 360 - 180
            hand_type = "left" if str(hand.type) == "HandType.Left" else "right"
            print(f"Hand id {hand.id} ({hand_type}): Palm yaw = {yaw:.2f}°")

            # Process only index finger (digit[1]) for pitch joint angles
            if len(hand.digits) > 1:
                digit = hand.digits[1]
                print("  Index finger joint pitch angles:")

                # Compute pitch of each bone segment relative to horizontal plane
                bone_pitches = []
                bone_names = ['Metacarpal', 'Proximal', 'Intermediate', 'Distal']
                for i, bone in enumerate(digit.bones):
                    pj = bone.prev_joint
                    nj = bone.next_joint
                    vx = nj.x - pj.x
                    vy = nj.y - pj.y
                    vz = nj.z - pj.z
                    horiz = math.sqrt(vx*vx + vz*vz)
                    # pitch: angle above horizontal
                    pitch = math.degrees(math.atan2(vy, horiz))
                    bone_pitches.append(pitch)
                    print(f"    {bone_names[i]} pitch = {pitch:.2f}°")

                # Compute joint pitch angle = difference between segments
                joint_labels = ["M-P", "P-I", "I-D"]
                for j in range(len(bone_pitches) - 1):
                    angle = abs(bone_pitches[j+1] - bone_pitches[j])
                    print(f"    {joint_labels[j]} joint rotation = {angle:.2f}°")
            else:
                print("  No index finger detected.")


def main():
    listener = MyListener()
    connection = leap.Connection()
    connection.add_listener(listener)

    with connection.open():
        connection.set_tracking_mode(leap.TrackingMode.Desktop)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("Stopping...")

if __name__ == "__main__":
    main()
