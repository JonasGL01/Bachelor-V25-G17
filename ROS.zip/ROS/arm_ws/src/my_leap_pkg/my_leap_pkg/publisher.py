#!/usr/bin/env python3
import math
import threading
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
from my_leap_pkg.leapc_cffi import ffi, libleapc

class LeapPublisher(Node):
    def __init__(self):
        super().__init__('leap_publisher')
        # Publish [palm_yaw, BOOM, ARM, BUCKET]
        self.pub = self.create_publisher(
            Float32MultiArray,
            'leap/control_angles',
            10
        )

        # LeapC connection
        self.conn = ffi.new("struct _LEAP_CONNECTION **")
        err = libleapc.LeapCreateConnection(ffi.NULL, self.conn)
        if err != libleapc.eLeapRS_Success:
            raise RuntimeError(f"LeapCreateConnection failed: {err}")
        err = libleapc.LeapOpenConnection(self.conn[0])
        if err != libleapc.eLeapRS_Success:
            raise RuntimeError(f"LeapOpenConnection failed: {err}")

        # Thread for continous poll
        thread = threading.Thread(target=self._poll_loop, daemon=True)
        thread.start()

    def _quantize(self, x, decimals=2):
        factor = 10 ** decimals
        return math.floor(x * factor + 0.5) / factor

    def _angle_asin(self, p_start, p_end):
        dx = p_end.x - p_start.x
        dy = p_end.y - p_start.y
        dz = p_end.z - p_start.z
        mag = math.sqrt(dy*dy + dz*dz)
        if mag == 0:
            return 0.0
        # deg
        raw_deg = math.degrees(math.asin(dy / mag))
        # return radians
        return math.radians(raw_deg)

    def _angle_acos(self, p_start, p_end):
        dx = p_end.x - p_start.x
        dy = p_end.y - p_start.y
        dz = p_end.z - p_start.z
        horiz = math.hypot(dy, dz)

        # output is deg
        raw_deg = math.degrees(math.acos(dz/horiz))
        # return rad
        return math.radians(raw_deg)

    def _poll_loop(self):
        while rclpy.ok():
            msg_ptr = ffi.new("LEAP_CONNECTION_MESSAGE *")
            res = libleapc.LeapPollConnection(self.conn[0], 100, msg_ptr)
            if res != libleapc.eLeapRS_Success:
                continue

            msg = msg_ptr[0]
            if msg.type != libleapc.eLeapEventType_Tracking:
                continue

            te = ffi.cast("LEAP_TRACKING_EVENT *", msg.tracking_event)[0]
            if te.nHands == 0:
                continue
            hand = te.pHands[0]

            #Yaw (rot)
            pd = hand.palm.direction
            mag_yaw = math.sqrt(pd.x*pd.x + pd.z*pd.z)
            if mag_yaw == 0:
                raw_yaw_deg = 0.0
            else:
                raw_yaw_deg = math.degrees(math.asin(pd.x / mag_yaw))
            raw_yaw_rad = math.radians(raw_yaw_deg)
            yaw_scaled = raw_yaw_rad * 1.13 + 0.48
            yaw_q = self._quantize(yaw_scaled)

            # Beregn BOOM, ARM, BUCKET for hver finger
            boom_vals = []
            arm_vals = []
            bucket_vals = []
            for idx in [1, 2, 3, 4]:
                digit = hand.digits[idx]
                m_start = digit.bones[0].prev_joint
                g_start = digit.bones[1].prev_joint
                i_start = digit.bones[2].prev_joint
                d_end   = digit.bones[3].next_joint

                # BOOM 
                boom_rad = self._angle_asin(m_start, g_start)
                boom = boom_rad
                boom_vals.append(boom)

                # ARM
                arm_rad = self._angle_asin(g_start, i_start)
                arm = arm_rad
                arm_vals.append(arm)

                # BUCKET
                bucket_rad = self._angle_acos(i_start, d_end)
                bucket = bucket_rad
                bucket_vals.append(bucket)

            # GjAverage
            avg_boom   = self._quantize(sum(boom_vals)   / len(boom_vals)) * 1.6 + 1.9
            avg_arm    = self._quantize(sum(arm_vals)    / len(arm_vals)) * 1.5 + 3.04
            avg_bucket = self._quantize(sum(bucket_vals) / len(bucket_vals)) * 0.7 + 1.12

            # Publish
            out = Float32MultiArray()
            out.data = [yaw_q, avg_boom, avg_arm, avg_bucket]
            self.pub.publish(out)

            # Debug log
            self.get_logger().info(f"Palm yaw = {yaw_q:.2f} rad")
            self.get_logger().info("Aggregated link pitch angles (rad):")
            self.get_logger().info(f"  BOOM   = {avg_boom:.2f}")
            self.get_logger().info(f"  ARM    = {avg_arm:.2f}")
            self.get_logger().info(f"  BUCKET = {avg_bucket:.2f}")

    def destroy_node(self):
        libleapc.LeapCloseConnection(self.conn[0])
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = LeapPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
