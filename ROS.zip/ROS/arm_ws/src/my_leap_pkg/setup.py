from setuptools import setup

package_name = 'my_leap_pkg'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name,
              'my_leap_pkg.leap',
              'my_leap_pkg.leapc_cffi'],
    install_requires=[
        'setuptools',
        'rclpy',
        'std_msgs',
        'numpy',
        'leapc_cffi',
        'leap',
    ],
    entry_points={
        'console_scripts': [
            'publisher = my_leap_pkg.publisher:main',
            'tracking_example = my_leap_pkg.tracking_example:main'
        ],
    },
    # <<< Add this block >>>
    data_files=[
        # Ament resource index—tells ROS 2 about your package
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        # Install package.xml into share/<package>
        ('share/' + package_name, ['package.xml']),
    ],
)
